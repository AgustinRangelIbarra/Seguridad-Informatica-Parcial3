package mx.ipn.upiicsa.segsw.labicla.util;


public class SecurityUtility {
	
	private static final String PASSWORD_RULES = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,}";
	private static final String EMAIL_RULES = "^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$";
	private static final String NAME_RULES = "[A-Za-z]+";
	private static final String ENTRY_RULES = "[A-Za-z\\d$@$!%*?&\\s]+";
	
	public static boolean isPasswordStrong(String password){
		return password.matches(PASSWORD_RULES);
	}
	
	public static boolean isEmailCorrect(String email) {
		return email.matches(EMAIL_RULES);
	}
	
	public static boolean isNameCorrect(String firstname) {
		return firstname.matches(NAME_RULES);
	}
	
	public static boolean isEntryCorrect(String blogEntryValue) {
		return blogEntryValue.matches(ENTRY_RULES);
	}
	
	public static void main(String[] args)
	{
		System.out.println(isPasswordStrong("Ab1234567_"));
	}
	

}
