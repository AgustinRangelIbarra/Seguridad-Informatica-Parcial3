package mx.ipn.upiicsa.segsw.labicla.dao;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import mx.ipn.upiicsa.segsw.labicla.valueobject.UsuarioValueObject;

public class UsuarioDAO {
	String respuesta = null;
	
	public UsuarioValueObject authenticate(String email, String password)
	{
		UsuarioValueObject user = null;
		String urlString = ("http://35.235.124.40:8000");
		String jsonString = ("{ \"word\" : \"" + password + "\", \"key\" : \"key\", \"type\": \"encode\",\"response\":\"\"}");
		
		String cifrado = Cifrado(urlString,jsonString);
		System.out.println("Esto se va a mandar a autenticar: " + cifrado);
		
		urlString = ("http://35.235.124.40:80/SegInfo_Root/autenticar.php");
		jsonString = ("{ \"email\" : \"" + email + "\", \"password\" : \"" + cifrado + "\"}");
		System.out.println(" ");
		System.out.println("URLSTRING: " + urlString);
		System.out.println("jsonString: " + jsonString);
		
		String respuestar = Post_JSON(urlString,jsonString);
		System.out.println(respuestar);
			
			if(respuestar.equals("\"true\"")) // Encontro un registro -- Credenciales validas
			{
				user = new UsuarioValueObject();	
				
				user.setEmail(email);
				user.setPassword(password);
				user.setFirstname("Juan");
				return user;
			}
			else
			{
				return null;
			}
	}

	public UsuarioValueObject findById(String email)
	{
		UsuarioValueObject user = null;
		String urlString = ("http://35.235.124.40/SegInfo_Root/userfindbyid.php");
		String jsonString = ("{ \"email\" : \"" + email + "\"}");
		
		System.out.println(jsonString);
		
		String respuestar = Post_JSON(urlString,jsonString);
		
		
			if(respuestar.equals("{}")) // El usuario no existe
			{
				return null;
			}
			else
			{
				user = new UsuarioValueObject();
				
				user.setEmail(email);
				user.setFirstname("firstname");
				user.setLastname("lastname");
				user.setStatus("status");
				
				return user;
			}
	}
	
	public UsuarioValueObject create(UsuarioValueObject user)
	{
		String urlString = ("http://35.235.124.40/SegInfo_Root/usercreate.php");
		String jsonString = ("{ \"email\" : \"" + user.getEmail() + "\",\"firstname\" : \"" + user.getFirstname() + "\", \"password\" : \"" + user.getPassword() + "\", \"lastname\" : \"" + user.getLastname() + "\", \"DaysOfPasswordValidity\" : \""
				+ user.getDaysOfPasswordValidity() + "\", \"isTemporalPassword\" : \"" + user.isTemporalPassword() +"\", \"ActivationKey\" : \"" + 
				user.getActivationKey() + "\", \"Status\" : \"" + user.getStatus() + "\",\"Qiz1\" : \"" + user.getQiz1() + "\", \"Qiz2\" : \"" + user.getQiz2() + "\",\"Qiz3\":\"" + user.getQiz3() + "\" }");
		System.out.println(jsonString);
		
		Post_JSON(urlString,jsonString);
		return user;
	}
	
	public UsuarioValueObject recuperar(String email, String qiz1, String qiz2, String qiz3)
	{
		String urlString = ("http://35.235.124.40/SegInfo_Root/userrecuperar.php");
		String jsonString = ("{ \"email\" : \"" + email + "\",\"qiz1\" : \"" + qiz1 + "\", \"qiz2\" : \"" + qiz2 + "\",\"qiz3\":\"" + qiz3 + "\" }");
		UsuarioValueObject user = new UsuarioValueObject();
		System.out.println("Esto se va a mandar" + jsonString);
		String query_url = urlString;
        String json = jsonString;
        try {
            URL url = new URL(query_url);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("POST");
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes("UTF-8"));
            os.close();
            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            
            String result = IOUtils.toString(in, "UTF-8");
          
            JSONObject myResponse = new JSONObject(result);

            Map<String, Object> objectMap = myResponse.toMap();
            objectMap.forEach((key, value) -> {

                JSONObject myResponse2 = myResponse.getJSONObject(key);
                Map<String, Object> objectMap2 = myResponse2.toMap();
                objectMap2.forEach((key2, value2) -> {
                	System.out.println(value2.toString());
                	if(key2.equals("email")) user.setEmail(value2.toString());
                	if(key2.equals("firstname")) user.setFirstname(value2.toString());
                	if(key2.equals("lastname")) user.setLastname(value2.toString());
                	if(key2.equals("password")) user.setPassword(value2.toString());
                });
            }); 
            
            in.close();
            conn.disconnect();
        }
		catch (Exception e) {
            System.out.println(e);
        }
        urlString = ("http://35.235.124.40:8000");
        jsonString = ("{ \"word\" : \"" + user.getPassword() + "\", \"key\" : \"key\", \"type\": \"decode\",\"response\":\"\"}");
        String pass = Cifrado(urlString,jsonString);
        user.setPassword(pass);
        return user;
	}

    public String Post_JSON(String urlString, String jsonString) {
    	
    	String query_url = urlString;
        String json = jsonString;
        try {
            URL url = new URL(query_url);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("POST");
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes("UTF-8"));
            os.close();
            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            String result = IOUtils.toString(in, "UTF-8");
            System.out.println(result);
            respuesta=result;
            if(urlString.equals("http://35.235.124.40/SegInfo_Root/userfindbyid.php")) {
            	respuesta = result;
            	in.close();
                conn.disconnect();
                return respuesta;
            }
            else {
            	System.out.println("Entrando en el servidor post");
            	JSONObject myResponse = new JSONObject(result);
                JSONObject product = myResponse.getJSONObject("response");
                
        		java.util.Map<String, Object> objectMap =  product.toMap();
        		objectMap.forEach((key, value) -> {
                    if (key.equals("access")) {
                        if (value.equals("true")) {    
                        	respuesta = (String) value;
                        	System.out.println(key + ":" + value);
                        }
                        else {
                        	respuesta = (String) value;
                        	System.out.println(key + ":" + value);
                        }
                    }
                }); 

                in.close();
                conn.disconnect();	
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return respuesta;
    }

    public String Cifrado (String urlString, String jsonString) {
    	String hash = null;
    	String query_url = urlString;
        String json = jsonString;
        try {
            URL url = new URL(query_url);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("POST");
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes("UTF-8"));
            os.close();
            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            String result = IOUtils.toString(in, "UTF-8");
            System.out.println(result);
            System.out.println("result after Reading JSON Response");
            JSONObject myResponse = new JSONObject(result);
            System.out.println("password: " + myResponse.getString("response"));
            hash = myResponse.getString("response");
            System.out.println("Esta es la clave cifrada: "+ hash);
            in.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println(e);
        }
		return hash;
    }

	public void closeConnection() {
		// TODO Auto-generated method stub
		
	}
}
