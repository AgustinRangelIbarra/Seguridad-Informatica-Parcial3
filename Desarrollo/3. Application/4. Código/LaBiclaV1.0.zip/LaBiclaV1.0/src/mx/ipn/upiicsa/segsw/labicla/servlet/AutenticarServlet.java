package mx.ipn.upiicsa.segsw.labicla.servlet;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.ipn.upiicsa.segsw.labicla.dao.UsuarioDAO;
import mx.ipn.upiicsa.segsw.labicla.valueobject.ErrorValueObject;
import mx.ipn.upiicsa.segsw.labicla.valueobject.UsuarioValueObject;


@WebServlet("/autenticar.controller")
public class AutenticarServlet extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;
       
    
    public AutenticarServlet() {
        super();
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		System.out.println("AutenticarServlet");
		ErrorValueObject error = null;
		
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		UsuarioDAO dao = null;
		UsuarioValueObject user = null;

		dao = new UsuarioDAO();
		user = dao.authenticate(email, password);
			
		if(user != null) // Credenciales validas
		{
			RequestDispatcher rd = request.getRequestDispatcher("main.jsp");
			request.getSession().setAttribute("user", user);
			rd.include(request, response);
			return;
		}
		else // Las credenciales NO son validas
		{
			error = new ErrorValueObject();
			
			error.setMessage("Credenciales no validas");
			error.setDescription("Las credenciales proporcionadas no son correctas.");
				
			request.setAttribute("error", error);
				
			RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
			rd.forward(request, response);
		}
		
	}

	
}
