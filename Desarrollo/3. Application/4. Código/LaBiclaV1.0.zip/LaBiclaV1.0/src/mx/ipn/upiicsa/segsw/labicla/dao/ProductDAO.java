package mx.ipn.upiicsa.segsw.labicla.dao;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import mx.ipn.upiicsa.segsw.labicla.valueobject.ProductValueObject;


public class ProductDAO
{	
	//Ver detalles del producto, se selecciona por id de producto

public ProductValueObject findById(Integer id)
	{
	ProductValueObject product = new ProductValueObject();
	
	String urlString = ("http://35.235.124.40:80/SegInfo_Root/productfindbyid.php");
	String jsonString = ("{ \"id\" : \"" + id + "\"}");
	String query_url = urlString;
    String json = jsonString;
    try {
        URL url = new URL(query_url);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(5000);
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setDoInput(true);
        conn.setRequestMethod("POST");
        OutputStream os = conn.getOutputStream();
        os.write(json.getBytes("UTF-8"));
        os.close();
        // read the response
        InputStream in = new BufferedInputStream(conn.getInputStream());
        
        String result = IOUtils.toString(in, "UTF-8");
      
        JSONObject myResponse = new JSONObject(result);

        Map<String, Object> objectMap = myResponse.toMap();
        objectMap.forEach((key, value) -> {
        	//product = new ProductValueObject();
            JSONObject myResponse2 = myResponse.getJSONObject(key);
            Map<String, Object> objectMap2 = myResponse2.toMap();
            objectMap2.forEach((key2, value2) -> {           	
            	if(key2.equals("id")) product.setId(Integer.parseInt(value2.toString()));
            	if(key2.equals("name")) product.setName(value2.toString());
            	if(key2.equals("description")) product.setDescription(value2.toString());
            	if(key2.equals("brand")) product.setBrand(value2.toString());
            	if(key2.equals("price")) product.setPrice(Float.parseFloat(value2.toString()));
            	if(key2.equals("quantity")) product.setQuantity(Integer.parseInt(value2.toString()));
             	if(key2.equals("image")) product.setImage(value2.toString());
            });
        }); 
        
        in.close();
        conn.disconnect();
    }
	catch (Exception e) {
        System.out.println(e);
    }
	System.out.println(product);
    return product;
}

	
	//Busqueda de productos por nombre
public List<ProductValueObject> findByCriteria(String criteria)
	{		
		List<ProductValueObject> productList = new ArrayList<ProductValueObject>();
		
		String urlString = ("http://35.235.124.40:80/SegInfo_Root/buscarservlet.php");
		String json = ("{ \"criteria\" : \"" + criteria + "\"}");

		try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("POST");
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes("UTF-8"));
            os.close();
            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            
            String result = IOUtils.toString(in, "UTF-8");
      
            JSONObject myResponse = new JSONObject(result);

            Map<String, Object> objectMap = myResponse.toMap();
            objectMap.forEach((key, value) -> {
        		ProductValueObject product = new ProductValueObject();

                JSONObject myResponse2 = myResponse.getJSONObject(key);
                Map<String, Object> objectMap2 = myResponse2.toMap();
                objectMap2.forEach((key2, value2) -> {
                	
                	if(key2.equals("id")) product.setId(Integer.parseInt(value2.toString()));
                	if(key2.equals("name")) product.setName(value2.toString());
                	if(key2.equals("description")) product.setDescription(value2.toString());
                	if(key2.equals("brand")) product.setBrand(value2.toString());
                	if(key2.equals("price")) product.setPrice(Float.parseFloat(value2.toString()));
                	if(key2.equals("quantity")) product.setQuantity(Integer.parseInt(value2.toString()));
                 	if(key2.equals("image")) product.setImage(value2.toString());

                });
            productList.add(product);
            }); 

            in.close();
            conn.disconnect();
        }
		catch (Exception e) {
            System.out.println(e);
        }
		return productList;
	}

}
