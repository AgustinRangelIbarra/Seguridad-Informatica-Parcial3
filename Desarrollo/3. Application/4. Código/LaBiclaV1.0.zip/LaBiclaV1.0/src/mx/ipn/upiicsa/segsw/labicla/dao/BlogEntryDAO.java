
package mx.ipn.upiicsa.segsw.labicla.dao;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import mx.ipn.upiicsa.segsw.labicla.exception.DAOInitializationException;
import mx.ipn.upiicsa.segsw.labicla.valueobject.BlogEntryValueObject;



public class BlogEntryDAO
{
	String respuesta = null;
	
	
	public void create(BlogEntryValueObject blogEntry)
	{
		System.out.println("Entrando a blog create");
		String urlString = ("http://35.235.124.40:80/SegInfo_Root/blogecreate.php");
		String jsonString = ("{ \"email\" : \"" + blogEntry.getUserEmail() + "\", \"value\" : \"" + blogEntry.getValue() + "\"}");
		System.out.println("Esto se va a mandar" + jsonString);
		String query_url = urlString;
        String json = jsonString;
        try {
            URL url = new URL(query_url);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("POST");
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes("UTF-8"));
            os.close();
            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            
            String result = IOUtils.toString(in, "UTF-8");
            System.out.println("resultado sin JSONObject: " + result + " - "  + result.getClass().getName());

            in.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println(e);
        }

	}

	public void delete(int id)
	{
		System.out.println("Entrando a blog delete");
		String urlString = ("http://35.235.124.40:80/SegInfo_Root/blogedelete.php");
		String jsonString = ("{ \"id\" : \"" + id + "\"}");
		
		String query_url = urlString;
        String json = jsonString;
        try {
            URL url = new URL(query_url);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("POST");
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes("UTF-8"));
            os.close();
            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            
            String result = IOUtils.toString(in, "UTF-8");
            System.out.println("resultado sin JSONObject: " + result + " - "  + result.getClass().getName());

            in.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println(e);
        }
	}

	public void update(BlogEntryValueObject blogEntry)
	{

		System.out.println("Entrando a blog UPDATE");
		String urlString = ("http://35.235.124.40:80/SegInfo_Root/blogeupdate.php");
		String jsonString = ("{ \"id\" : \"" + blogEntry.getId() + "\",\"blog-entry-value\" : \"" + blogEntry.getValue() + "\"}");
		System.out.println("Esto se va a mandar" + jsonString);
		String query_url = urlString;
        String json = jsonString;
        try {
            URL url = new URL(query_url);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("POST");
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes("UTF-8"));
            os.close();
            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            
            String result = IOUtils.toString(in, "UTF-8");
            System.out.println("resultado sin JSONObject: " + result + " - "  + result.getClass().getName());

            in.close();
            conn.disconnect();
        }
		catch (Exception e) {
            System.out.println(e);
        }
	
	}

	@SuppressWarnings("deprecation")
	public List<BlogEntryValueObject> findByCriteria(String criteria) throws DAOInitializationException
	{
		String urlString = ("http://35.235.124.40:80/SegInfo_Root/blogefindbycriteria.php");
		String json = ("{ \"criteria\" : \"" + criteria + "\"}");
		
		List<BlogEntryValueObject> blogEntryList = new ArrayList<BlogEntryValueObject>();

		try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("POST");
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes("UTF-8"));
            os.close();
            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            
            String result = IOUtils.toString(in, "UTF-8");
      
            JSONObject myResponse = new JSONObject(result);

            Map<String, Object> objectMap = myResponse.toMap();
            objectMap.forEach((key, value) -> {
        		BlogEntryValueObject blogEntry = new BlogEntryValueObject();

                JSONObject myResponse2 = myResponse.getJSONObject(key);
                Map<String, Object> objectMap2 = myResponse2.toMap();
                objectMap2.forEach((key2, value2) -> {
                	
                	if(key2.equals("id")) blogEntry.setId(Integer.parseInt(value2.toString()));
                	if(key2.equals("user_email")) blogEntry.setUserEmail(value2.toString());
                	if(key2.equals("entry_value")) blogEntry.setValue(value2.toString());
                	if(key2.equals("registration_date")) blogEntry.setRegistrationDate(new Date("Thu Nov 21 18:28:15 GMT 2019"));
                });
			blogEntryList.add(blogEntry);
            }); 

            in.close();
            conn.disconnect();
        }
		catch (Exception e) {
            System.out.println(e);
        }
			return blogEntryList;
	}
	
	
	@SuppressWarnings("deprecation")
	public BlogEntryValueObject findById(int id) 
	{
		BlogEntryValueObject blogEntry = new BlogEntryValueObject();

		System.out.println("Entrando a blog FINDBY ID");
		String urlString = ("http://35.235.124.40:80/SegInfo_Root/blogefindbyid.php");
		String jsonString = ("{ \"id\" : \"" + id + "\"}");
		System.out.println("Esto se va a mandar" + jsonString);
		String query_url = urlString;
        String json = jsonString;
        try {
            URL url = new URL(query_url);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("POST");
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes("UTF-8"));
            os.close();
            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            
            String result = IOUtils.toString(in, "UTF-8");
          
            JSONObject myResponse = new JSONObject(result);

            Map<String, Object> objectMap = myResponse.toMap();
            objectMap.forEach((key, value) -> {

                JSONObject myResponse2 = myResponse.getJSONObject(key);
                Map<String, Object> objectMap2 = myResponse2.toMap();
                objectMap2.forEach((key2, value2) -> {
                	
                	System.out.println(value2.toString());
                	if(key2.equals("id")) blogEntry.setId(Integer.parseInt(value2.toString()));
                	if(key2.equals("user_email")) blogEntry.setUserEmail(value2.toString());
                	if(key2.equals("entry_value")) blogEntry.setValue(value2.toString());
                	//if(key2.equals("registration_date")) blogEntry.setRegistrationDate(new Date(value2.toString()));
                	if(key2.equals("registration_date")) blogEntry.setRegistrationDate(new Date("Thu Nov 21 18:28:15 GMT 2019"));
                });
            }); 
            
            in.close();
            conn.disconnect();
        }
		catch (Exception e) {
            System.out.println(e);
        }
        return blogEntry;
	}
	
}

