package mx.ipn.upiicsa.segsw.labicla.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mx.ipn.upiicsa.segsw.labicla.dao.BlogEntryDAO;
import mx.ipn.upiicsa.segsw.labicla.util.SecurityUtility;
import mx.ipn.upiicsa.segsw.labicla.util.Utility;
import mx.ipn.upiicsa.segsw.labicla.valueobject.BlogEntryValueObject;
import mx.ipn.upiicsa.segsw.labicla.valueobject.UsuarioValueObject;



@WebServlet("/register_blog_entry.controller")

public class RegisterBlogEntryServlet extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterBlogEntryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
    	System.out.println("Entrando a REGISTER BLOG SERVLET");
		BlogEntryDAO dao = null;
		BlogEntryValueObject blogEntryValueObject = null;
		UsuarioValueObject user = (UsuarioValueObject) request.getSession().getAttribute("user");
		System.out.println(user);
		
		if( user  == null)
		{
			request.setAttribute("message", "Debe firmarse al sistema para registrar entradas en el blog.");
			RequestDispatcher rd = request.getRequestDispatcher("main.jsp");
			rd.forward(request, response);
			return;
		}
		String blogEntryValue = request.getParameter("blog-entry-value");
		
		if(Utility.containsAnEmptyValue(blogEntryValue))
		{
			request.setAttribute("message", "No puedes dejar el campo vacio");
			
			RequestDispatcher rd = request.getRequestDispatcher("main.jsp");
			rd.forward(request, response);
			return;
		}
		else if(SecurityUtility.isEntryCorrect(blogEntryValue) == false){
			request.setAttribute("message", "Caracter invalido11");
			
			RequestDispatcher rd = request.getRequestDispatcher("main.jsp");
			rd.forward(request, response);
			return;
		}
		
			dao = new BlogEntryDAO();
			
			blogEntryValueObject = new BlogEntryValueObject();
			
			blogEntryValueObject.setValue(blogEntryValue);
			blogEntryValueObject.setUserEmail(user.getEmail());
			
			dao.create(blogEntryValueObject);
			
			RequestDispatcher rd = request.getRequestDispatcher("get_blog_info.controller");
			rd.forward(request, response);
			return;

	}
}



