package mx.ipn.upiicsa.segsw.labicla.servlet;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mx.ipn.upiicsa.segsw.labicla.dao.UsuarioDAO;
import mx.ipn.upiicsa.segsw.labicla.util.Utility;
import mx.ipn.upiicsa.segsw.labicla.valueobject.ErrorValueObject;

import mx.ipn.upiicsa.segsw.labicla.valueobject.UsuarioValueObject;


@WebServlet("/recuperar_pass.controller")
public class RecuperarPasswordServlet extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;
	
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		System.out.println("CambiarPasswordServlet.doGet()");
		
		ErrorValueObject error = null;
		
		String email = request.getParameter("email");
		String qiz1 = request.getParameter("qiz1");
		String qiz2 = request.getParameter("qiz2");
		String qiz3 = request.getParameter("qiz3");
		
		if(Utility.containsAnEmptyValue(email,qiz1,qiz2,qiz3))
		{
			
			error = new ErrorValueObject();
			
			error.setMessage("Parametro faltante");
			error.setDescription("Falt&oacute; capturar algun campo obligatorio.");
			
			request.setAttribute("error", error);
			
			RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
			rd.forward(request, response);

			return;
		}
		///////////////////////////////////////////////////////////////////////////
		UsuarioDAO dao = null;
		UsuarioValueObject user = null;
		
		dao = new UsuarioDAO();
		user = dao.recuperar(email, qiz1, qiz2,qiz3);
		System.out.println("Esto se recupero: "+ user);
			
		if(user != null) // Contrase�a encontrada
		{
			request.setAttribute("message", "Tu contrase�a es: " + user.getPassword());
				
			RequestDispatcher rd = request.getRequestDispatcher("main.jsp");
			rd.forward(request, response);
			return;		
		}
		else // Las credenciales NO son validas
		{
			error = new ErrorValueObject();
				
			error.setMessage("Credenciales no validas");
			error.setDescription("Las credenciales proporcionadas no son correctas.");
				
			request.setAttribute("error", error);
				
			RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
			rd.forward(request, response);
			}
		}
		
	}	
